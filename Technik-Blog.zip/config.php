<?php

	/**************************/
	/* Database Configuration */
	/**************************/

	// The database server name or IP address \\
	    $server = "localhost";

	// The database username to connect with \\
	    $user = "root";
	
	// The database password to connect with \\
	    $password = "passwort";
	
	// The name of the database to select \\
	    $database = "Blog";

	// The Username of the Admin User \\		
		$benutzer = "admin";
		
	// The Passwort of the Admin User \\			
		$passwort = "admin";
?>