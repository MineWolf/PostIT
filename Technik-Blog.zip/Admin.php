<?php

	header("Location: ./Admin-Login.php");

?>